const fs = require("fs");
var validator = require("validator");
const dataPath = "./server/data/users.json";

// helper methods
/**
 * reads data from provided file path
 */
const readFile = (
  callback,
  returnJson = false,
  filePath = dataPath,
  encoding = "utf8"
) => {
  fs.readFile(filePath, encoding, (err, data) => {
    if (err) {
      console.log(err);
    }
    if (!data) data = "{}";
    callback(returnJson ? JSON.parse(data) : data);
  });
};
/**
 * Writes data to the given file path
 */
const writeFile = (
  fileData,
  callback,
  filePath = dataPath,
  encoding = "utf8"
) => {
  fs.writeFile(filePath, fileData, encoding, (err) => {
    if (err) {
      console.log(err);
    }
    callback();
  });
};
const validate_Movie_Details = (Body_Request, res, Must_Field) => {
  /**
   * Executes validation on all movie's provided details in the body request.
   */
  let i = 0;
  let Body_Request_Key = Object.keys(Body_Request);
  let boolean_llegal_fields = false;
  let illegalFields = "Illegal fields:\n";
  let check_missed_fields = false;
  let missedFields = "Missed required fields:\n";
  let checkInputs = false;
  let wrongInputs = "Wrong Inputs:\n";
  let finalErrorString = "";
  Body_Request_Key.forEach((key) => {
    i++;
    if (!Must_Field.includes(key)) {
      boolean_llegal_fields = true;
      illegalFields += ` : ${i}) ${key}\n`;
    }
  });
  i = 0;
  Must_Field.forEach((key) => {
    i++;
    if (!Body_Request_Key.includes(key)) {
      check_missed_fields = true;
      missedFields += ` : ${i}) ${key}\n`;
    }
  });
  let name = Body_Request.name;
  let director = Body_Request.director;
  let rating = Body_Request.rating;
  let isSeries = Body_Request.isSeries;
  let picture = Body_Request.picture;
  let date = Body_Request.date;
  let series_details = Body_Request.series_details;
  i = 0;
  i++;
  if (typeof name !== "string") {
    checkInputs = true;
    wrongInputs += ` : ${i}) name must be String\n`;
  }
  i++;
  if (typeof director !== "string") {
    checkInputs = true;
    wrongInputs += ` : ${i}) director must be String\n`;
  }
  i++;
  if (
    isNaN(rating) ||
    typeof rating === "boolean" ||
    rating < 1 ||
    rating > 5
  ) {
    checkInputs = true;
    wrongInputs += `: ${i}) rating must be number between 1 to 5\n`;
  }
  i++;
  if (typeof isSeries !== "boolean") {
    checkInputs = true;
    wrongInputs += ` : ${i}) isSeries must be boolean\n`;
  }
  i++;
  //check for URL to be valid
  if (!Body_Request.picture || !validator.isURL(picture)) {
    checkInputs = true;
    wrongInputs += ` : ${i}) picture must be valid url\n`;
  }
  // check date to be of valid format
  i++;
  if (
    !validator.isDate(date, "DD/MM/YYYY") &&
    !validator.isDate(date, "D/MM/YYYY") &&
    !validator.isDate(date, "D/M/YYYY") &&
    !validator.isDate(date, "DD/M/YYYY")
  ) {
    checkInputs = true;
    wrongInputs += ` : ${i}) date must be with the format DD/MM/YYYY\n`;
  }
  if (!Array.isArray(series_details)) {
    // must provide an array
    checkInputs = true;
    wrongInputs += `: *) series_details must be array\n`;
  } else {
    if (isSeries === false && series_details.length !== 0) {
      checkInputs = true;
      wrongInputs += ` : *) series_details must be empty array\n`;
    }
    if (isSeries === true && series_details.length === 0) {
      checkInputs = true;
      wrongInputs += ` : *) series_details can not br empty array\n`;
    }
    series_details.forEach((series_number) => {
      if (
        isNaN(series_number) ||
        typeof series_number === "boolean" ||
        series_number < 0
      ) {
        checkInputs = true;
        wrongInputs += ` : *) The value in the array series_details must be Integer\n`;
      }
    });
  }
  if (boolean_llegal_fields) {
    finalErrorString += illegalFields + "\n";
  }
  if (check_missed_fields) {
    finalErrorString += missedFields + "\n";
  }
  if (checkInputs) {
    finalErrorString += wrongInputs + "\n";
  }
  if (boolean_llegal_fields || check_missed_fields || checkInputs) {
    return res.status(400).send(finalErrorString);
  }
  return "Fixed";
};
const validateCreateActor = (Body_Request_actors, res, Must_Field) => {
  let name = Body_Request_actors.name;
  let picture = Body_Request_actors.picture;
  let site = Body_Request_actors.site;

  let actors_field = Object.keys(Body_Request_actors);
  let boolean_llegal_fields = false;
  let illegalFields = "Illegal fields:\n";

  let check_missed_fields = false;
  let missedFields = "Missed required fields:\n";

  let checkInputs = false;
  let wrongInputs = "Wrong Inputs:\n";

  let finalErrorString = "";
  let i = 0;
  actors_field.forEach((key) => {
    if (!Must_Field.includes(key)) {
      boolean_llegal_fields = true;
      illegalFields += `: ${i}) ${key}\n`;
    }
  });
  i = 0;
  Must_Field.forEach((key) => {
    if (!actors_field.includes(key)) {
      check_missed_fields = true;
      missedFields += `: ${i}) ${key}\n`;
    }
  });
  i = 0;
  if (!Body_Request_actors.name || typeof name !== "string") {
    checkInputs = true;
    wrongInputs += `: ${i}) name must be string\n`;
  }

  i++;
  if (!Body_Request_actors.picture || !validator.isURL(picture)) {
    checkInputs = true;
    wrongInputs += `: ${i}) picture must be valid url\n`;
  }
  i++;
  if (!Body_Request_actors.site || !validator.isURL(site)) {
    checkInputs = true;
    wrongInputs += `: ${i}) site must be valid url\n`;
  }
  if (boolean_llegal_fields) {
    finalErrorString += illegalFields + "\n";
  }
  if (checkInputs) {
    finalErrorString += wrongInputs + "\n";
  }
  if (check_missed_fields) {
    finalErrorString += missedFields + "\n";
  }
  if (boolean_llegal_fields || check_missed_fields || checkInputs) {
    return res.status(400).send(finalErrorString);
  }
  return "Fixed";
};
module.exports = {
  //READ
  read_movies: function (req, res) {
    /**
     * Fetches all movies from the movies.js file
     */
    fs.readFile(dataPath, "utf8", (err, data) => {
      if (err) {
        res.sendStatus(500).send(err);
      } else {
        res.send(!data ? JSON.parse("{}") : JSON.parse(data));
      }
    });
  },

  // CREATE
  create_movies: function (req, res) {
    /**
     * Creates new movie with provided details. Validates that the movie details are of the correct type,
     * and that the provided movieID does not already exist.
     */
    readFile((data) => {
      let Body_Request;
      let id_Body_Request;
      Body_Request = req.body;
      if (!Body_Request.id)
        return res
          .status(400)
          .send(`Bad Request Error. Missing required field (id)`);
      id_Body_Request = Body_Request.id;
      delete Body_Request["id"];
      if (data[id_Body_Request])
        return res
          .status(400)
          .send(`Movie with ID ${id_Body_Request} already exists!`);
      let Must_Field = [
        "name",
        "picture",
        "director",
        "date",
        "rating",
        "isSeries",
        "series_details",
      ];
      if (validate_Movie_Details(Body_Request, res, Must_Field) !== "Fixed")
        return;
      data[id_Body_Request] = {
        name: Body_Request.name,
        picture: Body_Request.picture,
        director: Body_Request.director,
        date: Body_Request.date,
        rating: Body_Request.rating,
        isSeries: Body_Request.isSeries,
        series_details: Body_Request.series_details,
        actors: {},
      };
      writeFile(JSON.stringify(data, null, 2), () => {
        res.status(200).send("new movie added");
      });
    }, true);
  },
  // UPDATE
  update_movie: function (req, res) {
    /**
     * Updates movie fields. Validates movieID exists, and that the other required fields are valid input.
     */
    readFile((data) => {
      const movieId = req.params["id"];
      let Body_Request;
      Body_Request = req.body[movieId] ? req.body[movieId] : req.body;
      if (Body_Request.id) {
        if (Body_Request.id !== movieId)
          return res.status(400).send(`Movie ID Mismatch!`);
      }
      if (!data[movieId]) {
        return res.status(404).send(`Movie with ID ${movieId} Not Found`);
      }
      let Must_Field = [
        "id",
        "name",
        "picture",
        "director",
        "date",
        "rating",
        "isSeries",
        "series_details",
      ];
      if (validate_Movie_Details(Body_Request, res, Must_Field) !== "Fixed")
        return;
      const arr = [
        "name",
        "picture",
        "director",
        "date",
        "rating",
        "isSeries",
        "series_details",
      ];
      let wantedKey = Object.keys(Body_Request);
      wantedKey.forEach((key) => {
        if (arr.includes(key)) {
          data[movieId][key] = Body_Request[key];
        }
      });
      writeFile(JSON.stringify(data, null, 2), () => {
        res.status(200).send(`movie id:${movieId} updated`);
      });
    }, true);
  },
  // DELETE
  delete_movie: function (req, res) {
    /**
     * Deletes movie from movies.js. Validates that movieID exists.
     */
    readFile((data) => {
      const movieId = req.params["id"];
      if (!data[movieId])
        return res.status(404).send(`Movie with ID ${movieId} does not exist!`);
      delete data[movieId];
      writeFile(JSON.stringify(data, null, 2), () => {
        res.status(200).send(`movie id:${movieId} removed`);
      });
    }, true);
  },
  AddActorToMovie: function (req, res) {
    /**
     * Adds actor under movie with the given movieID. Validates that the movie exists.
     */
    readFile((data) => {
      const movieId = req.params["id"];
      let Body_Request;
      if (!data[movieId]) {
        return res.status(404).send(`Movie with ID ${req.body.id} Not Found`);
      }
      const ActorName = req.params["name"];
      Body_Request = req.body[ActorName] ? req.body[ActorName] : req.body;
      let Must_Field = ["name", "picture", "site"];
      if (validateCreateActor(Body_Request, res, Must_Field) !== "Fixed")
        return;
      if (Body_Request.name) {
        if (Body_Request.name !== ActorName)
          return res.status(400).send(`Actor Name Mismatch!`);
        delete Body_Request["name"];
      }
      for (let actors in data[movieId].actors) {
        if (actors.toLowerCase() === ActorName.toLowerCase()) {
          return res
            .status(400)
            .send(`Actor with name ${ActorName} already exists!`);
        }
      }
      if (!Body_Request.picture || !Body_Request.site)
        return res.status(400).send(`One or more required fields empty!`);
      data[movieId].actors[ActorName] = {
        picture: Body_Request.picture,
        site: Body_Request.site,
      };
      writeFile(JSON.stringify(data, null, 2), () => {
        res.status(200).send(`movie id:${movieId} updated`);
      });
    }, true);
  },
  read_movies_by_ID: function (req, res) {
    /**
     * Receives movieID and fetches the requested movie. Validates that the movieID exists.
     */
    fs.readFile(dataPath, "utf8", (err, data) => {
      if (err) {
        return res.sendStatus(500).send(err);
      }
      const movieId = req.params["id"];
      let movies_json = JSON.parse(data);
      if (!movies_json[movieId])
        return res.status(404).send(`Movie with ID ${movieId} does not exist!`);
      let movie_json = movies_json[movieId];
      let movie_String = JSON.stringify(movie_json);
      res.status(200).send(movie_String);
    });
  },
  deleteActorFromMovie: function (req, res) {
    /**
     * Deletes actor from movie. Validates that actorID and movieID exist.
     */
    readFile((data) => {
      const movieId = req.params["id"];
      if (!data[movieId]) {
        return res.status(404).send(`Movie with ID ${req.body.id} Not Found`);
      }
      const ActorName = req.params["name"];
      let found = false;
      for (let actors in data[movieId].actors) {
        if (actors.toLowerCase() === ActorName.toLowerCase()) {
          found = true;
          delete data[movieId].actors[actors];
          break;
        }
      }
      if (!found) {
        return res
          .status(404)
          .send(`Actor with name ${ActorName} does not exist!`);
      }
      writeFile(JSON.stringify(data, null, 2), () => {
        res
          .status(200)
          .send(`Actor name: ${ActorName} in movie id: ${movieId} removed`);
      });
    }, true);
  },
};
